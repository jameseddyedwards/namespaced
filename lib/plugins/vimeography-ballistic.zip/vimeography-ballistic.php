<?php
/*
Plugin Name: Vimeography Theme: Ballistic
Plugin URI: http://www.vimeography.com/themes
Theme Name: Ballistic
Theme URI: vimeography.com/themes/ballistic
Version: 1.0.2
Description: is a simple list view of the videos from your Vimeo source.
Author: Dave Kiss
Author URI: http://www.vimeography.com/
Copyright: Dave Kiss
*/

if (! class_exists('Vimeography_Themes_Ballistic'))
{
  class Vimeography_Themes_Ballistic
  {
    public $version = '1.0.2';

    public function __construct()
    {
      add_action('plugins_loaded', array($this, 'load_theme'));
    }

    public function __set($name, $value)
    {
      $this->$name = $value;
    }

    /**
     * Has to be public so the wp actions can reach it.
     * @return [type] [description]
     */
    public function load_theme()
    {
      do_action('vimeography/load-theme', __FILE__);
    }

    public static function load_scripts()
    {
      wp_register_script('fitvids', VIMEOGRAPHY_ASSETS_URL.'js/plugins/jquery.fitvids.js', array('jquery'));
      wp_register_style('ballistic', plugins_url('media/ballistic.css', __FILE__));

      wp_enqueue_script('fitvids');
      wp_enqueue_style('ballistic');
    }

    public function videos()
    {
      // optional helpers
      require_once(VIMEOGRAPHY_PATH .'lib/helpers.php');
      $helpers = new Vimeography_Helpers;

      $videos = $helpers->apply_common_formatting($this->data);

      $items = array();

      foreach($videos as $item)
      {
        $item->oembed = $helpers->get_featured_embed($item->link);
        $items[] = $item;
      }

      return $items;
    }
  }

  new Vimeography_Themes_Ballistic;
}