=== Vimeography Ballistic ===
Contributors: iamdavekiss
Tags: vimeo
Requires at least: 3.3
Tested up to: 3.6.1
Stable tag: 1.0.2
License: MIT

The easiest way to create beautiful Vimeo galleries on your Wordpress blog.

== Description ==

Ballistic is a simple list view of the videos from your Vimeo source.

Make your gallery stand out with our custom themes!
[http://vimeography.com/themes](http://vimeography.com/themes "vimeography.com/themes")

For the latest updates, follow us!
[http://twitter.com/vimeography](http://twitter.com/vimeography "twitter.com/vimeography")

== Installation ==

1. Upload `vimeography-ballistic.zip` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==
= Help! My theme doesn't look right! =

Okay, deep breath. More than likely, it is another plugin causing this issue. See if you can pinpoint which one by disabling your plugins, one by one, and really determining if you need it. If that task sounds daunting, try disabling plugins that are used for photo galleries, minifying scripts, widgets, or otherwise alter your blog's appearance.

= Can I change the look of my Vimeography theme? =

Heck yeah! Use the appearance editor to change your theme's style so that it matches your site perfectly.

== Changelog ==

= 1.0.2 =
* Reduced filesize

= 1.0.1 =
* Removed 10 video limitation.

= 1.0 =
* Converted to plugin.

== Upgrade Notice ==
= 1.0 =
This update prevents your purchased themes from being publically accessible.